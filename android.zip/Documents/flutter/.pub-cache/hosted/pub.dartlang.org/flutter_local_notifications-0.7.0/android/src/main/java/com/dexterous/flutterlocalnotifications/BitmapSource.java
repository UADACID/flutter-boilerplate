package com.dexterous.flutterlocalnotifications;

public enum BitmapSource {
    Drawable,
    FilePath
}
